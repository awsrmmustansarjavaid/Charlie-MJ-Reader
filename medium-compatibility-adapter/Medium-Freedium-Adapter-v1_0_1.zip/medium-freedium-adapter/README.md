# Medium / Freedium Adapter

Adapter package for Charlie MJ Reader's built-in Medium compatibility integration.

## Install
1. Open Charlie MJ Reader Settings.
2. Open Medium Compatibility → Adapter Package Manager.
3. Choose this ZIP and confirm installation.
4. Ensure Freedium Reader and the Medium compatibility options are enabled.

## Behavior
- Detects Medium article URLs in the extension's built-in content integration.
- Hands Medium article URLs to `https://freedium-mirror.cfd/` when auto-open is enabled.
- Requests article HTML through the extension service worker and extracts article text/metadata from the mirror page.
- Supports the `show all` / `read more` expansion controls on the mirror.

This package is a compatibility manifest/documentation package. The ZIP importer stores adapter JavaScript as data and does not execute it. Actual execution remains in the extension's reviewed built-in code. It does not bypass authentication, paywalls, or site restrictions.
