/*
 * Data-only adapter reference for Medium / Freedium.
 * The current Charlie MJ Reader importer intentionally does not execute
 * imported adapter code. Runtime behavior is implemented in the extension's
 * reviewed src/content/content.js and src/background/service-worker.js.
 */
export const adapter = {
  id: "medium-freedium",
  matches: ["medium.com", "*.medium.com", "freedium-mirror.cfd"],
  serviceUrl: "https://freedium-mirror.cfd/",
  capabilities: ["handoff", "fetch-html", "extract-metadata", "extract-content"]
};
