/*
 * Medium / Freedium adapter descriptor for Charlie MJ Reader 1.1.6.
 *
 * SECURITY / RUNTIME NOTE:
 * This file is declarative reference data. Charlie MJ Reader's adapter
 * package importer stores imported JavaScript as data and does not execute it.
 * The extension's reviewed built-in content script and service worker perform
 * URL detection, Freedium handoff, page expansion, HTML retrieval and parsing.
 */
export const adapter = {
  id: "medium-freedium",
  version: "1.0.2",
  matches: ["medium.com", "*.medium.com", "freedium-mirror.cfd"],
  serviceUrl: "https://freedium-mirror.cfd/",
  serviceConfigKey: "settings.freediumServiceUrl",
  runtime: "builtin-reviewed-integration",
  capabilities: [
    "medium-url-detection",
    "freedium-handoff",
    "article-html-fetch",
    "extract-metadata",
    "extract-thumbnail",
    "extract-canonical-url",
    "expand-full-article",
    "extract-article-content"
  ],
  extraction: {
    title: ["meta[property='og:title']", "h1", "document.title"],
    description: ["meta[property='og:description']", "meta[name='description']"],
    image: ["meta[property='og:image']", "meta[name='twitter:image']", "article img"],
    author: ["meta[name='author']", "[rel='author']"],
    publishedAt: ["meta[property='article:published_time']", "time[datetime]"],
    contentRoots: [
      "article",
      "main",
      "[role='main']",
      "[data-testid='post-content']",
      ".post-content",
      ".article-content",
      ".article-body",
      ".post-body",
      ".story-content",
      ".reader-article",
      ".pw-post-body-paragraph",
      ".meteredContent",
      ".postArticle-content"
    ],
    expandLabels: ["show all", "read more"]
  }
};
