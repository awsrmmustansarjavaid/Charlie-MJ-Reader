# Medium / Freedium Adapter v1.0.2

Compatibility package for **Charlie MJ Reader 1.1.6** (and compatible restored builds).

## Install
1. Open Charlie MJ Reader.
2. Go to **Settings → Medium Compatibility → Adapter Package Manager**.
3. Import `Medium-Freedium-Adapter-v1_0_2.zip`.
4. Confirm replacement if an adapter with ID `medium-freedium` is already installed.
5. Keep the Medium/Freedium options enabled. The service URL can be changed in Medium Compatibility settings.

## Included compatibility metadata
- Medium host matching (`medium.com` and subdomains)
- Freedium mirror host matching (`freedium-mirror.cfd`)
- Freedium handoff and article HTML retrieval capability declarations
- Metadata and thumbnail discovery selectors
- Article content root selectors and expansion labels
- Canonical URL, author and publication-date metadata hints

## Important runtime behavior
This ZIP is a **declarative adapter package**, not an executable patch. The extension's ZIP importer stores JavaScript files as data and does not execute imported code. Actual Medium detection, Freedium navigation, page expansion, HTML retrieval and extraction are performed by Charlie MJ Reader's reviewed built-in content script and service worker. Importing this ZIP alone cannot replace or repair missing extension runtime code.

The mirror may not expose every field for every article. Thumbnail and metadata extraction depends on what the source page or mirror makes available, and pages that require authentication or block access may not be retrievable.
