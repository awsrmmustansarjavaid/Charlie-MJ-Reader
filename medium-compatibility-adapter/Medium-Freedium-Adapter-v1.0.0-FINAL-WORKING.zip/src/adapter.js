/* Charlie MJ Reader 1.0.0 — Medium/Freedium adapter descriptor.
 * Declarative metadata only. Runtime behavior is implemented by the extension.
 */
export const adapter = {
  id: "medium-freedium",
  version: "1.0.0",
  matches: ["medium.com", "*.medium.com", "freedium-mirror.cfd"],
  serviceUrl: "https://freedium-mirror.cfd/",
  serviceConfigKey: "settings.freediumServiceUrl",
  runtime: "builtin-reviewed-integration",
  capabilities: ["detect", "freedium-handoff", "fetch-html", "extract-content", "extract-metadata", "extract-thumbnail", "canonical-url", "structure-agnostic-article-root", "freedium-host-toolbar-inheritance", "challenge-page-rejection"],
  extraction: {
    title: ["meta[property='og:title']", "h1", "document.title"],
    description: ["meta[property='og:description']", "meta[name='description']"],
    image: ["meta[property='og:image']", "meta[name='twitter:image']", "article img"],
    author: ["meta[name='author']", "[rel='author']"],
    publishedAt: ["meta[property='article:published_time']", "time[datetime]"],
    // The built-in runtime first picks the container holding >=90% of the readable text (any story layout);
    // these selectors are only hints.
    rootStrategy: "largest-text-container",
    contentRoots: ["article", "main", "[role='main']", "[data-testid='post-content']", ".post-content", ".article-content", ".article-body", ".post-body", ".story-content", ".reader-article", ".pw-post-body-paragraph", ".meteredContent", ".postArticle-content"],
    expandLabels: ["show all", "read more"]
  }
};
