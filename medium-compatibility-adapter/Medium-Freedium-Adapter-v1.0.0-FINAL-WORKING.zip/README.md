# Medium / Freedium Adapter v1.0.0

Compatible with Charlie MJ Reader **1.0.0**.

## Install
1. Open the extension's Settings.
2. Open **Medium Compatibility → Adapter Package Manager**.
3. Select `Medium-Freedium-Adapter-v1.0.0.zip` using **ZIP package**.
4. Review the package details and confirm installation. If replacing an existing package with ID `medium-freedium`, confirm replacement.

The ZIP contains a root-level `adapter.json`, its declared `src/adapter.js` entry, and this README. The extension importer stores adapter files as data; it does not execute imported JavaScript. Medium/Freedium page fetching and extraction are performed by the extension's built-in code.

The adapter cannot bypass Medium authentication, paywalls, or access controls. The amount of content available depends on what Medium/Freedium returns for that article.

## Final fix notes
- Article extraction is structure-agnostic: any article length is accepted; no article-specific words, headings or word-count thresholds.
- Only verification / error pages (e.g. "Just a moment") are rejected, then the extension falls back to the live page.
- The Freedium mirror inherits Medium's supported-website status so the toolbar stays available there.
