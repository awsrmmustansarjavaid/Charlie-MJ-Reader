/* Charlie MJ Reader — declarative Medium/Freedium compatibility profile.
 * This file describes the runtime contract; imported adapter JavaScript is not executed.
 */
const FREEDIUM_BASE = "https://freedium-mirror.cfd/";
const MEDIUM_HOSTS = new Set(["medium.com"]);
function normalizeUrl(input) {
  try {
    const u = new URL(String(input).trim());
    if (!/^https?:$/.test(u.protocol)) return null;
    u.hash = "";
    ["source","utm_source","utm_medium","utm_campaign","utm_term","utm_content","sk"].forEach(k => u.searchParams.delete(k));
    return u.toString();
  } catch { return null; }
}
function matches(input) {
  const normalized = normalizeUrl(input); if (!normalized) return false;
  const host = new URL(normalized).hostname.toLowerCase();
  return MEDIUM_HOSTS.has(host) || host.endsWith(".medium.com") || host.endsWith(".pub");
}
function resolveReaderUrl(input, base = FREEDIUM_BASE) {
  const normalized = normalizeUrl(input);
  if (!normalized || !matches(normalized)) throw new Error("Not a supported Medium URL.");
  return String(base).replace(/\/+$/, "") + "/" + normalized.replace(/^\/+/, "");
}
const extraction = {
  fetchMode: "background-html-fetch",
  expandLabels: ["Show all", "Show all sections", "Read more"],
  completeArticleMarkers: ["1. dnsglobe", "10. gitlogue", "The Bigger Pattern", "Conclusion"],
  contentSelectors: ["article","main","[role=\"main\"]","[data-testid=\"post-content\"]",".post-content",".article-content",".article-body",".post-body",".story-content",".reader-article",".pw-post-body-paragraph",".meteredContent",".postArticle-content"],
  removeSelectors: ["script","style","noscript","nav","header","footer","aside","form","[aria-hidden=\"true\"]","[role=\"navigation\"]","[role=\"banner\"]","[role=\"contentinfo\"]","button","[role=\"button\"]"]
};
