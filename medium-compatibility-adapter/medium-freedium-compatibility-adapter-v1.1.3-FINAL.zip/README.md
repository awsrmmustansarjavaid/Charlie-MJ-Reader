# Medium / Freedium Compatibility Adapter

Version 1.1.3

This is the canonical Medium/Freedium compatibility package for Charlie-MJ-Reader v1.1.3.

## What changed in 1.1.3

The Reader no longer relies only on the visible/limited Medium DOM. For Medium and Freedium pages it can request the public Freedium HTML through the extension background service, parse that returned document, and select the complete long-form article.

The package declares:

- Medium URL normalization
- Freedium URL resolution using the full Medium URL as the Freedium path
- background HTML fetch for complete article capture
- complete-article markers and selectors
- metadata and image preservation
- automatic handling of Freedium "Show all", "Show all sections", and "Read more" controls

## Package layout

```text
adapter.json
adapter.js
sources.json
README.md
```

`adapter.json` is the required package manifest.

## Freedium URL format

`https://freedium-mirror.cfd/https://medium.com/...`

The source URL is appended as the Freedium path. It is not encoded as one opaque URL component.

## Security

Imported adapter JavaScript is retained as package data and is **not executed automatically**. The Charlie-MJ-Reader built-in runtime consumes the adapter declaratively.

## Important

This adapter package is intended to be used with Charlie-MJ-Reader v1.1.3 or newer. Installing the adapter alone does not turn arbitrary adapter JavaScript into executable code.
